# Sound design « Chauve-souris » — stems séparés

Tous les fichiers : WAV 48 kHz, 24 bits, stéréo, pleine durée, calés à 0, au niveau de mix voulu (la voix `01_voix.wav` = référence). `00_mix-de-reference.wav` = voix + toutes les pistes.

**Principe** : le sommeil est feutré (grotte, grenier, chambre chaude), puis le néon de Listen est le seul moment brillant. Tout est accroché aux mots de la voix ; si le calage bouge, relancer `scripts/sounddesign.py` suffit.

**Ce sont des sons synthétiques** (numpy), conçus pour être remplacés piste par piste par de vrais enregistrements aux mêmes instants (`sound-design.json`).

## 02_ambiance-grotte.wav
_Crête de piste : -33 dBFS._ L'air des lieux : la grotte (souffle grave, humidité), le grenier chaud et poussiéreux, la grotte d'hiver (vent sourd, froid), la chambre chaude presque silencieuse. Jamais de pluie ni de musique.

- 4.20 s — goutte

## 03_respiration-dormeur.wav
_Crête de piste : -28 dBFS._ Le souffle lent de la personne dans le lit : à la fin (chambre, 43,5 → fin) et pendant le plan chaud (35,9 → 38).

- 36.02 s — souffle calme
- 45.10 s — souffle calme

## 04_chauves-souris.wav
_Crête de piste : -26 dBFS._ Ailes de cuir qui se replient (froissement), cliquetis des griffes, colonie qui murmure (« en colonie ») et fantôme qui s'élève (« mourais »). Les cris de sonar sont sur la piste 09.

- 0.45 s — la chauve-souris traverse la lune
- 4.80 s — elle se retourne : tête en bas
- 11.45 s — griffes qui serrent
- 10.46 s — le fantôme s'élève
- 15.51 s — colonie
- 17.15 s — grenier
- 35.02 s — elle passe à la fenêtre

## 05_verrous-pieds.wav
_Crête de piste : -25 dBFS._ Les pieds qui se verrouillent : petit « clac » métallique sec sur chaque cadenas (« bloquent »), tendon qui se tend (grincement court).

- 8.22 s — tendons
- 8.62 s — cadenas

## 06_temperature-hiver.wav
_Crête de piste : -26 dBFS._ Le mercure qui chute sur « descendre » (glissando descendant), craquement de givre sur la grotte, puis le vent d'hiver (« cinq ou six mois ») et six lunes qui passent (tintements graves).

- 18.88 s — mercure qui descend
- 20.18 s — givre
- 20.91 s — vent d'hiver
- 23.31 s — lune
- 24.16 s — « mois »

## 07_badges-medaille.wav
_Crête de piste : -25 dBFS._ Les badges 1, 2, 3 (pop + petit tintement) sur chaque « nouvelle », tintements du cadran (16 → 20 h) et fanfare discrète de la médaille + confettis sur « champions ».

- 2.74 s — badge 1
- 13.10 s — badge 2
- 24.81 s — badge 3
- 28.44 s — tic du cadran
- 31.55 s — médaille
- 31.65 s — confettis

## 08_sonar-oreilles.wav
_Crête de piste : -27 dBFS._ « Elle voit le monde avec ses oreilles » : cris de sonar (chirps descendants rapides), échos qui reviennent de la mite et des troncs.

- 34.50 s — cri de sonar
- 34.78 s — écho
- 34.69 s — cri de sonar
- 34.98 s — cri de sonar
- 35.32 s — cri de sonar

## 09_listen-neon.wav
_Crête de piste : -25 dBFS._ Seul moment brillant : le téléphone s'allume (« Listen »), le néon s'étend en cercle, trois bulles (forêt, mer, montagne), le globe et ses repères, carillon + « pop » de la carte de fin.

- 38.11 s — le téléphone s'allume
- 38.50 s — le néon s'étend
- 39.04 s — bulle 1
- 39.48 s — bulle 2
- 40.13 s — bulle 3
- 40.30 s — le globe
- 41.15 s — repère 1
- 41.71 s — repère 2
- 42.07 s — repère 3
- 45.17 s — carte de fin : carillon
- 45.88 s — « lien en bio »

## 10_coupes.wav
_Crête de piste : -24 dBFS._ Impacts graves courts sur les coupes de plan (début de chaque scène sauf le premier plan).

- 2.68 s — coupe
- 7.98 s — coupe
- 9.56 s — coupe
- 13.04 s — coupe
- 16.94 s — coupe
- 17.82 s — coupe
- 20.56 s — coupe
- 24.76 s — coupe
- 28.40 s — coupe
- 30.72 s — coupe
- 32.32 s — coupe
- 34.28 s — coupe

## 11_retournement-lit.wav
_Crête de piste : -27 dBFS._ Le lit qui se retourne (0,2 → 1,8) : souffle d'air qui tourne, objets qui montent (froissements) ; à la fin, couette qui retombe et petit souffle d'endormissement.

- 0.15 s — le lit se retourne
- 0.50 s — objet qui monte
- 44.50 s — elle s'endort
