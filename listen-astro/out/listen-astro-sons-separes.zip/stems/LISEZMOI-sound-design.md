# Sound design « Astronaute » — stems séparés

Tous les fichiers : WAV 48 kHz, 24 bits, stéréo, pleine durée, calés à 0, au niveau de mix voulu (la voix `01_voix.wav` = référence). `00_mix-de-reference.wav` = voix + toutes les pistes.

**Principe** : la station est un lieu vivant (air, machines), dont on s'isole peu à peu : les bouchons assourdissent tout (piste 02), les souvenirs de la Terre sont presque silencieux (pas de pluie : ce serait l'appli qu'on entendrait), puis le néon de Listen est le seul moment brillant. Tout est accroché aux mots de la voix ; si le calage bouge, relancer `scripts/sounddesign.py` suffit.

**Ce sont des sons synthétiques** (numpy), conçus pour être remplacés piste par piste par de vrais enregistrements aux mêmes instants (`sound-design.json`).

## 02_ambiance-station.wav
_Crête de piste : -33 dBFS._ L'air d'une station : souffle grave, bourdonnement de machines. Presque rien dans la chambre du début et de la fin ; dense dans le tunnel (« bruit »), étouffé par les bouchons (« bouchons dans les oreilles » : tout s'assourdit) ; discret pendant les souvenirs de la Terre.


## 03_respiration-astronaute.wav
_Crête de piste : -26 dBFS._ L'astronaute endormi, au centre. Souffle lent et régulier dans le module (2,6 → 7), de plus en plus court et rauque quand l'air expiré reste autour de sa tête (7,5 → 12,2). S'arrête quand le ventilateur démarre.

- 2.60 s — souffle calme
- 5.90 s — souffle calme
- 8.02 s — souffle court
- 9.27 s — souffle court
- 10.39 s — souffle court
- 11.39 s — souffle court

## 04_ventilateurs.wav
_Crête de piste : -27 dBFS._ Les ventilateurs : démarrage en montée à « ventilateurs » (12,7), puis un ronronnement constant (plus présent quand on le voit : 12,3 → 14,9 et pendant le roulis 24,9 → 30,7) qui continue sous la suite, comme la nuit. S'éteint avec la carte.

- 12.28 s — démarrage du ventilateur

## 05_machines-bruit.wav
_Crête de piste : -27 dBFS._ La station qui vit : pompe qui bat (0,9 s), bips de voyants, trois ondes de bruit sur « bruit » (16,8), montée brillante sur « lumière » (17,8). Se coupe net avec la scène du soleil.

- 14.86 s — tunnel : pompe + bips
- 16.78 s — ondes de bruit sur « bruit »
- 17.78 s — montée de lumière sur « lumière »

## 06_soleil-x16.wav
_Crête de piste : -26 dBFS._ Le lever de soleil (montée chaude 19,2 → 20,4), puis 16 petits tintements qui s'accélèrent et montent en hauteur (même courbe que les 16 repères du cadran à l'image), et un impact brillant sur « ×16 ».

- 19.13 s — lever de soleil
- 20.39 s — repère 1
- 21.71 s — repère 16
- 20.49 s — « ×16 »

## 07_masque-bouchons.wav
_Crête de piste : -25 dBFS._ Le masque glisse (tissu), la sangle claque ; deux « pop » étouffés quand les bouchons se plantent, suivis d'un creux grave (l'oreille qui se bouche).

- 22.02 s — le masque glisse
- 22.47 s — la sangle claque
- 23.37 s — pop (bouchon gauche)
- 23.45 s — pop (bouchon droit)
- 23.42 s — creux grave (l'oreille se bouche)

## 08_roulis-haut-bas.wav
_Crête de piste : -26 dBFS._ Le roulis : grand souffle qui monte puis redescend (26,1 → 28,1) ; « haut » et « bas » qui s'apposent et se barrent (grattement de stylo) ; petit « tic » sur « accroché au mur ».

- 26.12 s — roulis
- 26.95 s — « haut » apparaît
- 27.13 s — barré (stylo)
- 27.35 s — « bas » apparaît
- 27.53 s — barré (stylo)
- 29.48 s — tic « accroché au mur »

## 09_souvenirs-terre.wav
_Crête de piste : -28 dBFS._ Le hublot qui devient un souvenir : montée douce et chaude à chaque changement (toit → terrasse → rue), un peu de parasite (crépitement) sur le bord, puis un petit « clic » par fenêtre qui s'éteint dans la rue. Aucun bruit de pluie, aucune musique (la voix porte).

- 32.63 s — souvenir : toit
- 35.19 s — souvenir : terrasse
- 36.62 s — souvenir : rue
- 37.85 s — souvenir : retour à la vraie vue
- 37.02 s — fenêtre qui s'éteint
- 30.82 s — badge 3

## 10_listen-neon.wav
_Crête de piste : -25 dBFS._ Le téléphone qui s'allume (glissando montant, 40,0), le néon qui s'étend (souffle montant, 40,5), trois bulles qui éclosent (bloop montants), le globe puis trois repères (pings), et à la carte de fin un carillon doux + un petit « pop » sur « lien en bio ». C'est le seul moment « coloré » de l'épisode : les sons sont plus brillants.

- 39.91 s — le téléphone s'allume
- 40.47 s — le néon s'étend
- 40.92 s — bulle 1
- 41.20 s — bulle 2
- 41.52 s — bulle 3
- 41.90 s — le globe
- 42.45 s — repère 1
- 43.35 s — repère 2
- 43.52 s — repère 3
- 45.79 s — carte de fin : carillon
- 46.49 s — « lien en bio »

## 11_coupes.wav
_Crête de piste : -24 dBFS._ Impacts graves courts sur les coupes (début de chaque plan). Aucun sur les raccords continus (le plan 3 de la bulle, le roulis, les souvenirs, le néon).

- 2.48 s — coupe
- 4.80 s — coupe
- 12.24 s — coupe
- 14.84 s — coupe
- 19.02 s — coupe
- 21.84 s — coupe
- 24.88 s — coupe
- 30.70 s — coupe
- 38.33 s — coupe
- 44.08 s — coupe

## 12_decollage.wav
_Crête de piste : -27 dBFS._ Le lit qui décolle : grand souffle d'air qui monte (0,1 → 2,3), étoiles qui scintillent (tintements aigus doux), froissements de couette et d'oreiller, léger grondement sourd qui monte.

- 0.05 s — décollage
- 0.30 s — étoile
- 0.25 s — objet qui se soulève
- 0.00 s — grondement sourd qui monte
