# Sound design « Dessous » — stems séparés

Tous les fichiers : WAV 48 kHz, 24 bits, stéréo, pleine durée (48,4 s), calés à 0, au niveau de mix voulu (la voix `01_voix.wav` = référence). `00_mix-de-reference.wav` = voix + toutes les pistes, pour écoute.

**Principe** : la chambre n'est jamais silencieuse, SAUF dans la pause de « … non » (37,0 → 37,9 s) où tout s'arrête d'un coup (ambiance, drone, cœur, souffle de Léa) : c'est le vrai choc de l'épisode. Le souffle de Léa (piste 03) se termine sur une inspiration jamais expirée ; ce que l'on entend ensuite (piste 12, le lit) est la même respiration, dix fois plus grave : c'est ce qu'il prenait pour Léa. Tout est coupé net au noir à 47,4 s, suivi de silence total.

**Ce sont des sons synthétiques** (numpy). Ils sont conçus pour être remplacés piste par piste par de vrais enregistrements (souffle, tissu, bois, sub) en gardant les mêmes instants ; la liste des évènements est dans `sound-design.json`.

## 02_ambiance-chambre.wav
_Crête de piste : -34 dBFS._ Chambre la nuit : air, un très léger ronflement de frigo/immeuble, jamais du silence numérique. S'éteint presque complètement dans la pause de « … non » (37,0 → 37,9), revient après.


## 03_respiration-lea.wav
_Crête de piste : -26 dBFS._ Léa, à droite, endormie. Cycles réguliers pendant tout le film ; le dernier (35,5 s) est une inspiration qui n'est JAMAIS expirée : c'est le moment où tout s'arrête.

- 0.20 s — souffle de Léa
- 3.41 s — souffle de Léa
- 6.63 s — souffle de Léa
- 9.84 s — souffle de Léa
- 13.05 s — souffle de Léa
- 16.27 s — souffle de Léa
- 19.48 s — souffle de Léa
- 22.70 s — souffle de Léa
- 25.91 s — souffle de Léa
- 29.12 s — souffle de Léa
- 32.34 s — souffle de Léa
- 35.55 s — inspiration (jamais expirée)

## 04_respiration-lui.wav
_Crête de piste : -24 dBFS._ Lui, au centre, très proche. Souffles courts et tremblants ; 3 inspirations nettes sur les « crans » (21,6 / 22,1 / 22,6) ; APNÉE de 24,4 à 26,8 ; grande aspiration rauque à « Je peux pas » ; souffle saccadé qui se calme jusqu'à 35.

- 3.75 s — souffle court (peur)
- 5.55 s — souffle court (peur)
- 6.40 s — souffle court (peur)
- 8.20 s — souffle court (peur)
- 10.30 s — souffle court (peur)
- 11.90 s — souffle court (peur)
- 13.70 s — souffle court (peur)
- 15.70 s — souffle court (peur)
- 17.50 s — souffle court (peur)
- 19.20 s — souffle court (peur)
- 21.60 s — inspiration sur un cran
- 22.12 s — inspiration sur un cran
- 22.60 s — inspiration sur un cran
- 26.62 s — GRANDE aspiration (« Je peux pas »)

## 05_coeur.wav
_Crête de piste : -22 dBFS._ Battement de cœur sourd (sub). Plus fort et plus rapide dans les plans « intérieurs » (paupières, yeux écarquillés), 140 bpm pendant l'apnée. S'arrête net à 36,95 s ; reprend lent et profond (52 bpm) à 38,0 et s'éteint vers 43.

- 3.20 s — cœur (lub-dub) 64 bpm
- 7.85 s — plan « paupières » : cœur étouffé, plus fort
- 24.40 s — apnée : le cœur s'emballe
- 26.80 s — pic (aspiration)
- 36.95 s — STOP net
- 38.00 s — reprise lente et profonde (52 bpm)

## 06_acouphene-interieur.wav
_Crête de piste : -38 dBFS._ Sifflement aigu très discret quand il ferme les yeux et dans le contrechamp de la panique : on est dans sa tête.

- 7.85 s — acouphène
- 9.65 s — acouphène
- 10.40 s — acouphène
- 25.60 s — acouphène

## 07_chaleur-impalpable.wav
_Crête de piste : -29 dBFS._ La chaleur, sans forme : souffle chaud grave qui pulse (~1 Hz), crépitements microscopiques dont la densité suit le front de chaleur (même courbe que l'image). Naît à 5,9 s, s'arrête avec le noir.

- 5.90 s — la chaleur naît (« Il y a un truc chaud »)
- 17.50 s — cran : « Là, c'est la cheville »
- 21.60 s — 3 crans sur les inspirations (21,6 / 22,1 / 22,6)
- 27.00 s — saut de deux crans (« Je peux pas »)
- 41.40 s — presque sur lui

## 08_humide.wav
_Crête de piste : -28 dBFS._ Sons mouillés étouffés (bulles, gel) : l'insert du drap (11,5 → 12,9), l'empreinte (13 → 14,1), un petit à chaque cran, et trois gouttes dans la marée finale. Jamais clair, toujours sous le reste.

- 6.85 s — humide
- 11.55 s — humide
- 11.90 s — humide
- 12.10 s — humide
- 12.45 s — humide
- 12.80 s — humide
- 13.20 s — humide
- 13.70 s — humide
- 14.05 s — humide
- 17.55 s — humide
- 18.30 s — humide
- 18.90 s — humide
- 19.60 s — humide
- 20.30 s — humide

## 09_drone-tension.wav
_Crête de piste : -27 dBFS._ Drone grave (~40-50 Hz + quinte + octave) qui monte avec la progression de la chaleur. S'éteint dans la pause de « non » (37,0 → 37,9), revient avec le lit. De 43,3 à 47,4 : marée montante, coupée net au noir.

- 5.40 s — le drone naît
- 21.00 s — monte avec les crans
- 37.00 s — SE TAIT (pause de « non »)
- 37.95 s — revient avec le lit
- 43.30 s — marée finale (montée)
- 47.40 s — COUPÉ NET (noir)

## 10_coupes-et-a-coups.wav
_Crête de piste : -23 dBFS._ Impacts graves courts (sub + queue de bruit) sur les coupes de plan ; gros sur « trop » (14,1) et sur l'aspiration (26,8). Aucun impact sur « non » (37,86) : le silence est le choc.

- 0.93 s — coupe
- 3.18 s — coupe
- 6.70 s — coupe
- 7.58 s — coupe
- 8.83 s — coupe
- 9.63 s — coupe
- 11.28 s — coupe
- 15.38 s — coupe
- 17.43 s — coupe
- 25.58 s — coupe
- 27.68 s — coupe
- 41.38 s — coupe
- 43.28 s — coupe
- 14.11 s — « trop » : l'empreinte serre

## 11_tissu-et-matelas.wav
_Crête de piste : -27 dBFS._ Frottements de tissu (oreiller, drap, sa main) et grincements du matelas, chaque fois que quelque chose bouge sous la couette. Le grincement du lit est ce qui trahit la chose.

- 0.95 s — tissu
- 3.20 s — tissu
- 17.40 s — tissu
- 21.30 s — tissu
- 26.80 s — tissu
- 28.85 s — tissu
- 29.90 s — tissu
- 33.70 s — tissu
- 35.80 s — tissu
- 43.40 s — tissu
- 17.50 s — grincement du matelas
- 18.25 s — grincement du matelas
- 22.00 s — grincement du matelas
- 22.50 s — grincement du matelas

## 12_le-lit-respire.wav
_Crête de piste : -23 dBFS._ La respiration du lit (sub + souffle grave) : inspiration 37,9 → 39,85 (le cadre monte), expiration 39,85 → 42,0 (déborde sous le noir et « Léa ? »). Prend la suite de la respiration de Léa, 10 fois plus grave : c'est ce qu'il prenait pour elle.

- 37.90 s — inspiration du lit
- 39.85 s — expiration du lit
- 43.30 s — inspiration (finale)

## 13_pause-et-final.wav
_Crête de piste : -26 dBFS._ Un souffle inversé presque inaudible qui monte dans les derniers 0,4 s du silence (37,5 → 37,86) et prépare l'entrée du lit ; un battement de cœur lent et grave à 42,1 (« Léa ? ») ; puis RIEN : coupe nette à 47,4 (noir) suivie de 1 s de silence total avant la boucle (aucun impact, aucune queue de réverbération).

- 37.50 s — souffle inversé (la pause se referme)
- 42.10 s — cœur lent sur « Léa ? »
